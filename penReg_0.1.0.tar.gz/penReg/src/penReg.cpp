#include <RcppArmadillo.h>
#include <RcppEnsmallen.h>
#include <Rcpp.h>
#include <math.h>
using namespace Rcpp;

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::depends("RcppEnsmallen")]]


// const double ADAPTIVE_LIMIT = 10;
// global variables for CD algorithm//
unsigned int maxiterCD = 100;
double epsCD = 1e-4;
double BETAMIN = 1e-4;
double MAX_EXP = 20;


// L1 lasso threshold function//
arma::vec L1softvecArma(arma::vec x, arma::vec y){
    arma::vec z = 1 -  y/arma::abs(x);
    for(unsigned int i=0; i<x.n_elem;i++){
        if(z(i)>0){
            z(i) = x(i)*z(i);
        }else{
            z(i) = 0;
        }
    }
    return z;
}


// group lasso threshold function //
arma::vec L1GsoftvecArma(arma::vec x, double y){
    double ss = 1-y/norm(x,2);
    if(ss>0){
        x=ss*x;
    }else{
        x.zeros();
    }
    return x;
}


// [[Rcpp::export]]
arma::vec calc_normBeta(const arma::mat& XY, const arma::umat& group){
    
    arma::vec res(group.n_rows);
    for(unsigned int k=0;k < group.n_rows;k++){
        arma::mat tmp = XY.rows(group(k,0),group(k,1));
        res(k) = arma::accu(arma::square(tmp)) / tmp.n_elem;
    }
    return arma::sqrt(res);
}


// [[Rcpp::export]]
arma::vec calc_normXY(const arma::mat& XY, const arma::umat& group){
    
    arma::vec res(group.n_rows);
    for(unsigned int k=0;k < group.n_rows;k++){
        arma::mat tmp = XY.rows(group(k,0),group(k,1));
        res(k) = arma::accu(arma::square(tmp));
    }
    return arma::sqrt(res);
}


//  group lasso penalty functions //
class OneGroupXXfun
{
public:
    const arma::mat& xx;
    const arma::vec& xy;
    const double lam;
    
    OneGroupXXfun(const arma::mat& xx, const arma::vec& xy, double lam) :
        xx(xx), xy(xy), lam(lam){
        
    }
    double EvaluateWithGradient(const arma::mat& beta , arma::mat& g)
    {
        // Rcout <<"e1\n";
        arma::vec bb = beta.col(0);
        double vv = std::sqrt( arma::accu(arma::square(bb)));
        g.col(0) = xx * bb - xy   + lam*bb/ vv;
        double fval = arma::as_scalar( 0.5 * bb.t() * xx * bb - bb.t() * xy) + lam*vv;
        return fval;
    }
};

// function to solve group lasso with one group
// 1/2 (beta^T XX beta - 2beta^T XY) +  \lam ||beta||_2 
arma::vec OneGroupXX(const arma::vec& XY, const arma::mat& XX, 
                     arma::vec beta, double lam){
    
    if(lam == 0){
        beta = arma::solve(XX,XY);
    }else if(arma::accu(arma::square(XY/lam)) <= 1){
        // determine if beta is all zero //
        beta.zeros();
    }else{
        // if not run the following
        OneGroupXXfun myfun(XX, XY, lam);
        ens::L_BFGS lbfgs;
        //lbfgs.MaxIterations() = 10;
        if(arma::all(beta==0)){
            beta.fill(BETAMIN);
        }
        lbfgs.Optimize(myfun, beta);
        beta.replace(arma::datum::nan, 0);
    }
    return beta;
}

//  function to perform group lasso
// 1/2 \sum_i w_i (y_i - x_i^T\beta)^2 +
// ridge/2 ||\beta||_2^2 + lam * \sum_g ||gvec[g] % beta_g||_2
// assume at least two groups
// [[Rcpp::export]]
arma::vec WLM_grplasso(const arma::vec& W, const arma::mat& X, const arma::vec& Y,
                       arma::vec beta, const arma::umat& grpid,
                       double lam, double ridge,  const arma::vec& ridge_gvec,
                       const arma::vec& gvec, 
                       double eps, int maxiter){
    
    // const int p = beta.n_elem;
    const int G = grpid.n_rows;
    int iter=0;
    
    arma::mat XW = X.each_col()%W;
    arma::field<arma::mat> XWX(G,1);
    for(int j=0;j<G;j++){
        XWX(j) = XW.cols(grpid(j,0),grpid(j,1)).t() * X.cols(grpid(j,0),grpid(j,1));
        XWX(j).diag() += ridge*ridge_gvec(j);
    }
    //arma::mat XWX = arma::trans(X.each_col()%W)*X;
    //arma::vec XWY = arma::trans(X)*(W%Y);
    
    double error = 1.0;
    arma::vec beta0 = beta;
    
    arma::vec Ytilde = Y - X.cols(grpid(1,0),grpid(G-1,1))*
        beta.subvec(grpid(1,0),grpid(G-1,1));
    
    while(error > eps and iter < maxiter){
        beta0 = beta;
        
        for(int j=0; j<G; j++){
            //beta(j) = 0;
            arma::vec xwy = XW.cols(grpid(j,0),grpid(j,1)).t()*Ytilde;
            arma::vec beta_s = beta.subvec(grpid(j,0),grpid(j,1));
            //Rcout << beta_s.t() << "\n";
            beta_s = OneGroupXX(xwy,XWX(j), beta_s,lam*gvec(j));
            //Rcout << beta_s.t() << "\n";
            beta.subvec(grpid(j,0),grpid(j,1)) = beta_s;
            
            if( arma::any(beta_s) ){
                Ytilde -=  X.cols(grpid(j,0),grpid(j,1))*
                    beta.subvec(grpid(j,0),grpid(j,1));
            }
            
            if(j<G-1){
                if( arma::any(beta.subvec(grpid(j+1,0),grpid(j+1,1))) ){
                    Ytilde = Ytilde + X.cols(grpid(j+1,0),grpid(j+1,1))*
                        beta.subvec(grpid(j+1,0),grpid(j+1,1));
                }
            }else{
                if( arma::any(beta.subvec(grpid(0,0),grpid(0,1))) ){
                    Ytilde = Ytilde + X.cols(grpid(0,0),grpid(0,1))*
                        beta.subvec(grpid(0,0),grpid(0,1));
                }
            }
        }
        
        error = arma::norm(beta-beta0)/std::sqrt(1.0*X.n_cols);
        //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
        iter ++;
    }
    
    //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
    return beta;
}



//  function to perform nested group lasso
// 1/2 \sum_i w_i (y_i - x_i^T\beta)^2 +
// ridge/2 ||\beta||_2^2 + lam * (\sum_g gvec[g] * || beta_g||_2)^2
// assume at least two groups
// [[Rcpp::export]]
arma::vec WLM_nestGrplasso(const arma::vec& W, const arma::mat& X, const arma::vec& Y,
                           arma::vec beta, const arma::umat& grpid,
                           double lam, double ridge,  const arma::vec& ridge_gvec, 
                           const arma::vec& gvec, 
                           double eps, int maxiter){
    
    // const int p = beta.n_elem;
    const int G = grpid.n_rows;
    int iter=0;
    
    arma::mat XW = X.each_col()%W;
    arma::field<arma::mat> XWX(G,1);
    for(int j=0;j<G;j++){
        XWX(j) = XW.cols(grpid(j,0),grpid(j,1)).t() * X.cols(grpid(j,0),grpid(j,1));
        XWX(j).diag() += ridge*ridge_gvec(j) + lam* gvec(j) * gvec(j);
    }
    //arma::mat XWX = arma::trans(X.each_col()%W)*X;
    //arma::vec XWY = arma::trans(X)*(W%Y);
    
    double error = 1.0, CC=0;
    arma::vec beta0 = beta;
    
    arma::vec Ytilde = Y - X.cols(grpid(1,0),grpid(G-1,1))*
        beta.subvec(grpid(1,0),grpid(G-1,1));
    
    for(int j = 1; j<G; j++){
        if(arma::any( beta.subvec(grpid(j,0),grpid(j,1)) )){
            CC += std::sqrt( arma::accu(arma::square(beta.subvec(grpid(j,0),grpid(j,1))))) * 
                gvec(j);
        }
    }
    
    while(error > eps and iter < maxiter){
        beta0 = beta;
        
        for(int j=0; j<G; j++){
            //beta(j) = 0;
            arma::vec xwy = XW.cols(grpid(j,0),grpid(j,1)).t()*Ytilde;
            arma::vec beta_s = beta.subvec(grpid(j,0),grpid(j,1));
            //Rcout << beta_s.t() << "\n";
            //arma::mat xwx = XWX(j);
            //xwx.diag() += lam* gvec(j) * gvec(j);
            beta_s = OneGroupXX(xwy, XWX(j), beta_s,lam*gvec(j)*CC);
            //Rcout << beta_s.t() << "\n";
            beta.subvec(grpid(j,0),grpid(j,1)) = beta_s;
            
            if( arma::any(beta_s) ){
                Ytilde -=  X.cols(grpid(j,0),grpid(j,1))*
                    beta.subvec(grpid(j,0),grpid(j,1));
                CC += std::sqrt( arma::accu(arma::square(beta_s))) *  gvec(j);
            }
            
            if(j<G-1){
                if( arma::any(beta.subvec(grpid(j+1,0),grpid(j+1,1))) ){
                    Ytilde = Ytilde + X.cols(grpid(j+1,0),grpid(j+1,1))*
                        beta.subvec(grpid(j+1,0),grpid(j+1,1));
                    CC -= std::sqrt( arma::accu(  arma::square(
                        beta.subvec(grpid(j+1,0),grpid(j+1,1))) )) *  gvec(j+1);
                }
            }else{
                if( arma::any(beta.subvec(grpid(0,0),grpid(0,1))) ){
                    Ytilde = Ytilde + X.cols(grpid(0,0),grpid(0,1))*
                        beta.subvec(grpid(0,0),grpid(0,1));
                    CC -= std::sqrt( arma::accu(  arma::square(
                        beta.subvec(grpid(0,0),grpid(0,1))) )) *  gvec(0);
                }
            }
        }
        
        error = arma::norm(beta-beta0)/std::sqrt(1.0*X.n_cols);
        //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
        iter ++;
    }
    
    //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
    return beta;
}


// function to approx the Binomial likelihood
// using quadratic functions
void defOut_Binom(const arma::vec &W, const arma::vec& Y,  const arma::mat& X, 
                  const arma::vec& beta,  arma::vec &w, arma::vec &z){
    
    arma::vec eta = X*beta;
    eta = arma::clamp(eta, -MAX_EXP, MAX_EXP);
    arma::vec Xeta = arma::exp(eta);
    arma::vec p = Xeta/(1+Xeta);
    arma::vec l = W% (p - Y);
    arma::vec ll = W% p % (1-p);
    z = eta - l/ll;
    w = ll;
}


// function to approx the Poisson likelihood
// using quadratic functions
void defOut_Pois(const arma::vec &W, const arma::vec& Y,  const arma::mat& X, 
                 const arma::vec& beta,  arma::vec &w, arma::vec &z){
    
    arma::vec eta = X*beta;
    eta = arma::clamp(eta, -MAX_EXP, MAX_EXP);
    arma::vec Xeta = arma::exp(eta);
    //arma::vec p = Xeta/(1+Xeta);
    arma::vec l = W % (Xeta- Y);
    arma::vec ll = W % Xeta;
    z = eta - l/ll;
    w = ll;
}


//  function to perform nested group lasso for binomial 
// 1/2 \sum_i w_i (y_i - x_i^T\beta)^2 +
// ridge/2 ||\beta||_2^2 + lam * (\sum_g gvec[g] * || beta_g||_2)^2
// assume at least two groups
// [[Rcpp::export]]
arma::vec BinomWLM_nestGrplasso(const arma::vec& W, const arma::mat& X,
                                const arma::vec& Y, arma::vec beta, 
                                const arma::umat& grpid,  double lam, 
                                double ridge,const arma::vec& ridge_gvec,  
                                const arma::vec& gvec,  
                                double eps, int maxiter){
    
    double err = 1.0;
    
    arma::vec betak=beta;
    int n = Y.n_elem;
    arma::vec w(n, arma::fill::zeros);
    arma::vec z(n, arma::fill::ones);
    int iter = 0;
    
    while(iter < maxiter and err > eps){
        
        // (1) approx the likelihood and calculate the new X,Y,W
        // Rcout << "start approx... \n";
        defOut_Binom(W,  Y,  X,  beta,  w, z);
        
        // Rcout << "start WLM... \n";
        // (2) use WLM to optimize the appox likelihood, i.e. weighted LS
        
        beta = WLM_nestGrplasso(w, X, z,  beta,  grpid,
                                lam,  ridge,  ridge_gvec, gvec, 
                                eps, maxiter);
        
        err = arma::norm(beta-betak,2)/sqrt(1.0*beta.n_elem);
        betak = beta;
        iter ++;
        
    }
    
    // Rcout << " Convergence stats: iterations=" << iter << "; error=" << err << "\n";
    
    return beta;
}


// [[Rcpp::export]]
arma::mat BinomWLM_nestGrplasso_seq(const arma::vec& W, const arma::mat& X,
                                const arma::vec& Y, arma::vec beta, 
                                const arma::umat& grpid,  arma::vec lam_seq, 
                                arma::vec ridge_seq, const arma::vec& ridge_gvec,  
                                const arma::vec& gvec,  
                                double eps, int maxiter){
    
    arma::mat beta_all(beta.n_elem, lam_seq.n_elem);
    arma::vec beta_tmp = beta;
    
    for(int j=0; j<lam_seq.n_elem; j++){
        double lam = lam_seq(j);
        double ridge = ridge_seq(j);
        
        beta_tmp = BinomWLM_nestGrplasso( W,  X, Y,  beta_tmp,  grpid,  lam, 
                                          ridge, ridge_gvec, gvec,  eps, maxiter);
        beta_all.col(j) = beta_tmp;
    }
   
    return beta_all;
}



// [[Rcpp::export]]
arma::vec BinomWLM_Grplasso(const arma::vec& W, const arma::mat& X,
                            const arma::vec& Y, arma::vec beta, 
                            const arma::umat& grpid,  double lam, 
                            double ridge,  const arma::vec& ridge_gvec,
                            const arma::vec& gvec, 
                            double eps, int maxiter){
    
    double err = 1.0;
    
    arma::vec betak=beta;
    int n = Y.n_elem;
    arma::vec w(n, arma::fill::zeros);
    arma::vec z(n, arma::fill::ones);
    int iter = 0;
    
    while(iter < maxiter and err > eps){
        
        // (1) approx the likelihood and calculate the new X,Y,W
        // Rcout << "start approx... \n";
        defOut_Binom(W,  Y,  X,  beta,  w, z);
        // Rcout << "start WLM... \n";
        
        // (2) use WLM to optimize the appox likelihood, i.e. weighted LS
        beta = WLM_grplasso(w, X, z,  beta,  grpid,
                                lam,  ridge,   ridge_gvec, gvec, 
                                eps, maxiter);
        err = arma::norm(beta-betak,2)/std::sqrt(1.0*beta.n_elem);
        betak = beta;
        iter ++;
        
    }
    
    // Rcout << " Convergence stats: iterations=" << iter 
    //     << "; error=" << err << "\n";
    
    return beta;
}

// [[Rcpp::export]]
arma::mat BinomWLM_Grplasso_seq(const arma::vec& W, const arma::mat& X,
                                    const arma::vec& Y, arma::vec beta, 
                                    const arma::umat& grpid,  arma::vec lam_seq, 
                                    arma::vec ridge_seq, const arma::vec& ridge_gvec,  
                                    const arma::vec& gvec,  
                                    double eps, int maxiter){
    
    arma::mat beta_all(beta.n_elem, lam_seq.n_elem);
    arma::vec beta_tmp = beta;
    
    for(int j=0; j<lam_seq.n_elem; j++){
        double lam = lam_seq(j);
        double ridge = ridge_seq(j);
        
        beta_tmp = BinomWLM_Grplasso( W,  X, Y,  beta_tmp,  grpid,  lam, 
                                      ridge, ridge_gvec, gvec,  eps, maxiter);
        beta_all.col(j) = beta_tmp;
    }
    
    return beta_all;
}


//  function to perform nested group lasso for binomial 
// 1/2 \sum_i w_i (y_i - x_i^T\beta)^2 +
// ridge/2 ||\beta||_2^2 + lam * (\sum_g gvec[g] * || beta_g||_2)^2
// assume at least two groups
// [[Rcpp::export]]
arma::vec PoisWLM_nestGrplasso(const arma::vec& W, const arma::mat& X,
                               const arma::vec& Y, arma::vec beta, 
                               const arma::umat& grpid,  double lam, 
                               double ridge, const arma::vec& ridge_gvec, 
                               const arma::vec& gvec, 
                               double eps, int maxiter){
    
    double err = 1.0;
    
    arma::vec betak=beta;
    int n = Y.n_elem;
    arma::vec w(n, arma::fill::zeros);
    arma::vec z(n, arma::fill::ones);
    int iter = 0;
    
    while(iter < maxiter and err > eps){
        
        Rcout << beta(0) << "... \n";
        // (1) approx the likelihood and calculate the new X,Y,W
        // Rcout << "start approx... \n";
        defOut_Pois(W,  Y,  X,  beta,  w, z);
        
        // Rcout << "start WLM... \n";
        // (2) use WLM to optimize the appox likelihood, i.e. weighted LS
        
        beta = WLM_nestGrplasso(w, X, z,  beta,  grpid,
                                lam,  ridge,   ridge_gvec, gvec, 
                                eps, maxiter);
        
        err = arma::norm(beta-betak,2)/sqrt(1.0*beta.n_elem);
        betak = beta;
        iter ++;
        
    }
    
    Rcout << " Convergence stats: iterations=" << iter << "; error=" << err << "\n";
    
    return beta;
}




// (sparse) group lasso penalty functions //
class BlockOneGroupXX
{
public:
    double xx;
    double xy;
    arma::vec bb;
    
    double lam1;
    double lam2;
    double ridge;
    
    
    BlockOneGroupXX(double xx, double xy, arma::vec bb,
                    double lam1,  double lam2, double ridge) :
        xx(xx), xy(xy),  bb(bb), lam1(lam1), lam2(lam2), ridge(ridge){
        
    }
    
    double EvaluateWithGradient(const arma::mat& beta , arma::mat& g)
    {
        // Rcout <<"e1\n";
        double b2 = beta(0,0)*beta(0,0);
        double vv = std::sqrt( arma::accu(arma::square(bb)) + b2 );
        g(0,0) = xx * beta(0,0) - xy   +
            lam1*arma::sign(beta(0,0)) + lam2*beta(0,0)/vv + ridge*beta(0,0);
        
        return 0.5*xx*b2 -xy*beta(0,0)  +  lam1*std::abs(beta(0,0)) +
            lam2*vv  + 0.5*ridge*b2;
    }
};


// coordinate-descent algorithm to solve sparse group lasso with one group
// 1/2 (beta^T XX beta - 2beta^T XY) + lam_1 ||avec%beta||_1 +
// \lam_2 ||beta||_2 + 0.5*ridge*||beta||_2^2
arma::vec CDSpGroupOneXX(arma::vec XY, arma::mat XX, arma::vec beta,
                         double lam1, arma::vec avec, double lam2, double ridge){
    
    // determine if beta is all zero //
    //arma::vec a = X.t()*Y;
    arma::vec t = XY - (lam1*avec)%arma::sign(XY);
    arma::uvec idx = arma::find(arma::abs(XY)<= lam1*avec);
    t.elem(idx).zeros();
    if(arma::accu(arma::square(t/lam2)) <= 1){
        beta.zeros();
    }else{
        // if not run the following
        const unsigned int p = beta.n_elem;
        unsigned int iter=0, j=0;
        
        BlockOneGroupXX myfun(0, 0, beta, lam1, lam2, ridge);
        ens::L_BFGS lbfgs;
        //lbfgs.MaxIterations() = 10;
        
        double error = 1.0;
        arma::vec beta0 = beta;
        double z = 0;
        arma::mat beta_tmp(1,1);
        
        while(error > epsCD and iter < maxiterCD){
            beta0 = beta;
            
            for(j=0; j<p; j++){
                beta_tmp(0,0) = beta(j);
                beta(j) = 0;
                z = XY(j) - arma::accu( XX.col(j)%beta );
                beta(j) = beta_tmp(0,0);
                
                if(std::abs(z) > lam1*avec(j)){
                    myfun.xx = XX(j,j);
                    myfun.xy = z;
                    myfun.lam1 = lam1*avec(j);
                    myfun.bb = beta;
                    myfun.bb(j) = 0;
                    if(arma::any(beta)){
                        beta_tmp(0,0) = beta(j);
                    }else{
                        beta_tmp(0,0) = BETAMIN;
                    }
                    lbfgs.Optimize(myfun, beta_tmp);
                    beta_tmp.replace(arma::datum::nan, 0);
                    beta(j) = beta_tmp(0,0);
                }else{
                    beta(j)=0;
                }
                
            }
            
            error = arma::norm(beta-beta0)/std::sqrt(1.0*p);
            //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
            iter ++;
        }
        
    }
    
    //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
    return beta;
}

//  function to perform lasso
// 1/2 \sum_i w_i (y_i - x_i^T\beta)^2 +
// ridge/2 ||\beta||_2^2 + lam ||avec % beta||_1
// [[Rcpp::export]]
arma::vec WLM_lasso(const arma::vec& W, const arma::mat& X, const arma::vec& Y,
                    arma::vec beta, double lam, double ridge, 
                    const arma::vec& ridge_avec,
                    const arma::vec& avec, double eps, int maxiter){
    
    const int p = beta.n_elem;
    int iter=0, j=0;
    
    arma::mat XW = X.each_col()%W;
    arma::vec XWX(p);
    for(j=0;j<p;j++){
        XWX(j) = arma::accu(XW.col(j) % X.col(j)) + ridge*ridge_avec(j);
    }
    //arma::mat XWX = arma::trans(X.each_col()%W)*X;
    //arma::vec XWY = arma::trans(X)*(W%Y);
    
    double error = 1.0;
    arma::vec beta0 = beta;
    double z = 0;
    
    arma::vec Ytilde = Y - X.cols(1,p-1)*beta.subvec(1,p-1);
    
    while(error > eps and iter < maxiter){
        beta0 = beta;
        
        for(j=0; j<p; j++){
            //beta(j) = 0;
            z = arma::accu( XW.col(j)%Ytilde );
            if(std::abs(z) > lam*avec(j)){
                beta(j) = z*(1-lam*avec(j)/std::abs(z))/ XWX(j);
            }else{
                beta(j)=0;
            }
            
            if(beta(j)!=0){
                Ytilde = Ytilde - X.col(j)*beta(j);
            }
            
            if(j<p-1){
                if(beta(j+1)!=0){
                    Ytilde = Ytilde + X.col(j+1)*beta(j+1);
                }
            }else{
                if(beta(0) !=0){
                    Ytilde = Ytilde + X.col(0)*beta(0);
                }
            }
        }
        
        error = arma::norm(beta-beta0)/sqrt(1.0*p);
        //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
        iter ++;
    }
    
    //Rcout << "Iterations: " << iter << ", error=" << error <<"\n";
    return beta;
}




// function to approx the partial likelihood
// using quadratic functions
void defOut_Surv(const arma::vec &ftime, const arma::uvec &fstat, const arma::vec &w,
                 const arma::vec &d, const arma::vec &UniTime, const arma::uvec &idx,
                 arma::vec eta, arma::vec &grad, arma::vec &H, arma::vec &R){
    
    
    eta = arma::clamp(eta, -20, 20);
    arma::vec Xeta = arma::exp(eta);
    arma::vec wEta = w%Xeta;
    double tmp = 0.0, total = arma::accu(wEta);
    
    int i=0, iter=0, flag=0;
    
    // calculate R:  \sum_{j\in R_i} w_j exp(x_j*beta) //
    // calculate Ctmp: \sum_{i\in c_k} d_i 1/(\sum_{j\in R_i} w_j exp(x_j*beta)) //
    // calculate Ctmp2: \sum_{i\in c_k} d_i 1/(\sum_{j\in R_i} w_j exp(x_j*beta))^2 //
    double Ctmp = 0.0, Ctmp2=0.0;
    
    for(i=0;i<ftime.n_elem;i++){
        if(fstat(i)==1){
            if(UniTime(iter) == ftime(i)){
                
                if(flag==0){
                    R(iter) = total-tmp;
                    flag = 1;
                    Ctmp +=  d(iter)/R(iter);
                    Ctmp2 +=  d(iter)/R(iter)/R(iter);
                }
            }else{
                flag=1;
                iter++;
                R(iter) = total-tmp;
                Ctmp +=  d(iter)/R(iter);
                Ctmp2 +=  d(iter)/R(iter)/R(iter);
            }
            grad(i) = Ctmp*wEta(i) - w(i);
            
        }else{
            grad(i) = Ctmp*wEta(i);
        }
        
        H(i) = Ctmp*wEta(i) - Ctmp2*wEta(i)*wEta(i);
        
        if(grad(i)!=0 or H(i)!=0){
            grad(i)  = grad(i)/H(i);
        }
        
        
        tmp += wEta(i);
        
        
    }
    
}



// function to optimize weighted partial likelihood
// with lasso penalty
// used in final estimation step
// [[Rcpp::export]]
arma::vec lasso_WCOX(const arma::mat& X, const arma::vec& ftime,
                     const arma::uvec& fstat, const arma::vec& W,
                     arma::vec beta, const arma::vec& avec,
                     const double lam1, const double ridge,
                     const arma::vec& ridge_avec,
                     const double eps, const int maxiter,
                     const bool verbose=false){
    
    //const arma::vec W = W_f / arma::accu(W_f.elem(arma::find(fstat==1)));
    
    int p = X.n_cols, n=X.n_rows, iter = 0, i = 0;
    //W = W/sum(W);
    
    arma::vec UniTime = arma::unique(ftime.elem(arma::find(fstat==1)));
    arma::vec d(UniTime.n_elem,arma::fill::zeros);
    arma::vec R(UniTime.n_elem,arma::fill::zeros);
    arma::uvec idx(n, arma::fill::zeros);
    
    for(i=0; i < n; i++){
        if(fstat(i)==1){
            if(UniTime(iter) == ftime(i)){
                d(iter) += W(i);
            }else{
                iter++;
                d(iter) += W(i);
            }
            idx(i) = iter;
        }
    }
    
    
    double err = 1.0;
    
    arma::vec betak=beta;
    arma::vec xb = X*betak;
    arma::vec lp(n, arma::fill::zeros);
    arma::vec lpp(n, arma::fill::ones);
    arma::vec newY(n, arma::fill::ones);
    
    iter = 0;
    while(iter < maxiter and err > eps){
        
        // (1) approx the likelihood and calculate the new X,Y,W
        //Rcout << "start approx... \n";
        xb = X*betak;
        defOut_Surv(ftime, fstat, W, d, UniTime, idx, xb, lp, lpp, R);
        newY = xb - lp;
        
        //Rcout << "start ADMM... \n";
        // (2) use ADMM to optimize the appox likelihood, i.e. weighted LS
        
        
        beta = WLM_lasso(lpp, X, newY, betak, lam1,
                         ridge, ridge_avec, avec,  eps,  maxiter);
        
        err = arma::norm(beta-betak,2)/sqrt(1.0*p);
        betak = beta;
        
        iter ++;
        
    }
    
    if(verbose){
        Rcout << "      Convergence stats: iterations=" << iter << "; error=" << err << "\n";
    }
    
    return beta;
}


// [[Rcpp::export]]
double get_gamma_vec(const arma::vec& x){
    arma::mat x_mat = arma::repmat(x,1,x.n_elem);
    arma::mat y_mat = arma::repmat(x.t(),x.n_elem,1);
    double val = arma::accu(arma::abs(x_mat - y_mat))/x.n_elem/(x.n_elem-1);
    return 1/val/val;
}


arma::mat minus_outer(const arma::vec& x, 
                      const arma::vec& y){
    
    arma::mat x_mat = arma::repmat(x,1,y.n_elem);
    arma::mat y_mat = arma::repmat(y.t(),x.n_elem,1);
    return arma::abs( x_mat - y_mat);
}

// [[Rcpp::export]]
double get_gamma_list(const arma::field<arma::vec>& x){
    
    double res = 0;
    long int n = 0;
    for(int i=0;i < x.n_elem; i++){
        for(int j=i+1; j < x.n_elem; j++){
            arma::mat tmp = minus_outer(x(i), x(j));
            res += arma::accu(tmp);
            n += tmp.n_elem;
        }
    }
    
    // arma::mat tmp = minus_outer(x(0), x(1));
    // Rcout << tmp.submat(0,0,5,5) << "\n";
    // Rcout << tmp.n_elem << "\n";
    // Rcout << tmp.n_rows << "\n";
    // Rcout << tmp.n_cols << "\n";
    // Rcout << "res=" << res<< "\n";
    // Rcout << "n=" << n<< "\n";
    double val = res / n;
    return 1/val/val;
}


arma::mat plus_outer(const arma::vec& x, 
                     const arma::vec& y){
    
    arma::mat x_mat = arma::repmat(x,1,y.n_elem);
    arma::mat y_mat = arma::repmat(y.t(),x.n_elem,1);
    return x_mat + y_mat;
}



double exp_outer(const arma::vec& x, 
                 const arma::vec& y, 
                 double gamma){
    
    arma::mat x_mat = arma::repmat(x,1,y.n_elem);
    arma::mat y_mat = arma::repmat(y.t(),x.n_elem,1);
    
    arma::mat res = arma::exp( - gamma * arma::square(x_mat - y_mat));
    return arma::accu(res) * 1.0 / res.n_elem;
}

// [[Rcpp::export]]
arma::mat get_KT_gram(const arma::field<arma::vec>& x, const double gamma){

    arma::mat res(x.n_elem, x.n_elem);

    for(int i=0;i < x.n_elem; i++){
        for(int j=i; j < x.n_elem; j++){
            res(i,j) = exp_outer(x(i), x(j), gamma);
        }
    }

    res = arma::symmatu(res);
    res = plus_outer(res.diag(), res.diag()) - 2*res;
    
    double gamma_2 = arma::accu(arma::sqrt(res))/res.n_rows/(res.n_rows-1);
    gamma_2 = 1/gamma_2/gamma_2;
    
    return arma::exp(-gamma_2*res);
}



double exp_outer_sum(const arma::vec& x, 
                 const arma::vec& y, 
                 double gamma){
    
    arma::mat x_mat = arma::repmat(x,1,y.n_elem);
    arma::mat y_mat = arma::repmat(y.t(),x.n_elem,1);
    
    arma::mat res = arma::exp( - gamma * arma::square(x_mat - y_mat));
    return arma::accu(res);
}

// [[Rcpp::export]]
arma::mat get_KT_gram_sum(const arma::field<arma::vec>& x, const double gamma){
    
    arma::mat res(x.n_elem, x.n_elem);
    
    for(int i=0;i < x.n_elem; i++){
        for(int j=i; j < x.n_elem; j++){
            if(x(i).has_nan() or x(j).has_nan()){
                res(i,j) = 0;
            }else{
                res(i,j) = exp_outer_sum(x(i), x(j), gamma);
            }
            
        }
    }
    
    res = arma::symmatu(res);
    res = plus_outer(res.diag(), res.diag()) - 2*res;
    
    double gamma_2 = arma::accu(arma::sqrt(res))/res.n_rows/(res.n_rows-1);
    gamma_2 = 1/gamma_2/gamma_2;
    
    return arma::exp(-gamma_2*res);
}



// [[Rcpp::export]]
double get_sigma_list(const arma::field<arma::vec>& x){
    
    double res = 0;
    long int n = 0;
    for(int i=0;i < x.n_elem; i++){
        for(int j=i+1; j < x.n_elem; j++){
            arma::mat tmp = minus_outer(x(i), x(j));
            res += arma::accu(tmp);
            n += tmp.n_elem;
        }
    }

    double val = res / n;
    return val;
}

double exp_outer_flex(const arma::vec& x, 
                     const arma::vec& y, 
                     double gamma, bool Gaus=true){
    
    arma::mat x_mat = arma::repmat(x,1,y.n_elem);
    arma::mat y_mat = arma::repmat(y.t(),x.n_elem,1);
    
    arma::mat res;
    if(Gaus){
        res = arma::exp( - gamma * arma::square(x_mat - y_mat));
    }else{
        res = arma::exp( - gamma * arma::abs(x_mat - y_mat));
    }
    
    
    
    return arma::accu(res);
}

// [[Rcpp::export]]
arma::mat get_KT_gram_flex(const arma::field<arma::vec>& x, const double sigma,
                           bool Gaus_1=true, bool Gaus_2=true, 
                           const double Gaus_factor=1.0){
    
    arma::mat res(x.n_elem, x.n_elem);
    double gamma;
    if(Gaus_1){
        gamma = Gaus_factor/sigma/sigma;
    }else{
        gamma = 1.0/sigma;
    }
    
    for(int i=0;i < x.n_elem; i++){
        for(int j=i; j < x.n_elem; j++){
            if(x(i).has_nan() or x(j).has_nan()){
                res(i,j) = 0;
            }else{
                res(i,j) = exp_outer_flex(x(i), x(j), gamma, Gaus_1);
            }
            
        }
    }
    
    res = arma::symmatu(res);
    res = plus_outer(res.diag(), res.diag()) - 2*res;
    
    double sigma_2 = arma::accu(arma::sqrt(res))/res.n_rows/(res.n_rows-1);
    double gamma_2;
    
    if(Gaus_2){
        gamma_2 = Gaus_factor/sigma_2/sigma_2;
        res = arma::exp(-gamma_2*res);
    }else{
        gamma_2 = 1.0/sigma_2;
        res = arma::exp(-gamma_2*arma::sqrt(res));
    }
    
   
    
    return res;
}

// // [[Rcpp::export]]
// double test_list(const arma::field<arma::vec>& x){
//     
//     for(int i=0;i < x.n_elem; i++){
//         Rcout << x(i) << "\n";
//         if(x(i).has_nan()){
//             Rcout << i << "has nan\n" ;
//         }
//     }
//     
//     return 0;
// }

// // [[Rcpp::export]]
// arma::mat test_mat(arma::mat res){
//     res = arma::symmatu(res);
//     return res;
// }
//     




